public class Client {
    public static void main1(int choice) {
        ProgramInterface p;
        if (choice == 1)      p = new Program1();
        else if (choice == 2) p = new Program2();
        else if (choice == 3) p = new Program3();
        else { System.out.println("Unknown program: " + choice); return; }
        System.out.println("I am main1");
        p.go();
    }
// main2 and main3: the exact same if/else block, copied
}
