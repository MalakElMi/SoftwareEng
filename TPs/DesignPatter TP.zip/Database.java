public class Database{
    private static Database instance;
    private String name;

    private Database(String name) {
        this.name = name;
    }

    public static synchronized Database getInstance(String name) {
        if (instance == null) {
            instance = new Database(name);
        }
        return instance;
    }

    public String getName() {
        return name;
    }

    public void getConnection() {
        System.out.println("You are connected to the database " + name);
    }

    public static void main(String[] args){
        Database db1 = Database.getInstance("Students");
        Database db2 = Database.getInstance("Teachers");

        db1.getConnection();
        db2.getConnection();

        System.out.println("Do both references point to the same instance? "+ (db1==db2));

    }

}